
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, getDocs, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyBjYPyVv9qC88JGD8N1tnDZLT0hh1sZUtQ",
  authDomain: "locator-66521.firebaseapp.com",
  projectId: "locator-66521",
  storageBucket: "locator-66521.appspot.com",
  messagingSenderId: "322028471975",
  appId: "1:322028471975:web:ee77430c76935588187d82",
  measurementId: "G-S87YVN1RX4"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

window.register = function () {
  const email = document.getElementById('email').value;
  const pass = document.getElementById('password').value;
  createUserWithEmailAndPassword(auth, email, pass).then(() => {
    alert("Registered!");
  }).catch(console.error);
};

window.login = function () {
  const email = document.getElementById('email').value;
  const pass = document.getElementById('password').value;
  signInWithEmailAndPassword(auth, email, pass).then(() => {
    alert("Logged in!");
  }).catch(console.error);
};

onAuthStateChanged(auth, user => {
  if (user) {
    document.getElementById('profile-form').style.display = 'block';
    document.getElementById('status-form').style.display = 'block';
    loadDashboard();
  }
});

window.submitProfile = async function () {
  const name = document.getElementById('name').value;
  const designation = document.getElementById('designation').value;
  const photo = document.getElementById('photo').files[0];

  const storageRef = ref(storage, 'photos/' + auth.currentUser.uid);
  await uploadBytes(storageRef, photo);
  const photoURL = await getDownloadURL(storageRef);

  await setDoc(doc(db, "users", auth.currentUser.uid), {
    name, designation, photoURL,
    status: { Monday: "", Tuesday: "", Wednesday: "", Thursday: "", Friday: "" }
  });
  alert("Profile Saved");
};

window.updateStatus = async function () {
  const day = document.getElementById('day').value;
  const status = document.getElementById('status').value;
  const userRef = doc(db, "users", auth.currentUser.uid);
  const userSnap = await getDoc(userRef);
  const userData = userSnap.data();
  userData.status[day] = status;
  await updateDoc(userRef, { status: userData.status });
  alert("Status Updated");
  loadDashboard();
};

async function loadDashboard() {
  const querySnapshot = await getDocs(collection(db, "users"));
  const table = document.getElementById('staff-table');
  table.innerHTML = "";
  querySnapshot.forEach(docSnap => {
    const data = docSnap.data();
    const row = `<tr>
      <td><img src="${data.photoURL}" width="50"></td>
      <td>${data.name}</td>
      <td>${data.designation}</td>
      <td>${data.status?.Monday || ""}</td>
      <td>${data.status?.Tuesday || ""}</td>
      <td>${data.status?.Wednesday || ""}</td>
      <td>${data.status?.Thursday || ""}</td>
      <td>${data.status?.Friday || ""}</td>
    </tr>`;
    table.innerHTML += row;
  });
}
